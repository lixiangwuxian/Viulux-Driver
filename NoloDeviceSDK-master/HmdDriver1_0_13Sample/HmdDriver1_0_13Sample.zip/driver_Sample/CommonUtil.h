#pragma once

#define SafeDelte(p) if(p!=nullptr){delete p;p=nullptr;}

