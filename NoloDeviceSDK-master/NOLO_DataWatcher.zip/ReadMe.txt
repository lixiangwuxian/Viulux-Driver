本程序用于观察Nolo数据是否正常流动。
步骤1. 打开 NoloServer.exe
步骤2. 打开 NOLO_Windows.exe
步骤3. 将NOLO 头盔定位器通过USB线，连接到电脑。

然后观察数据是否正常！